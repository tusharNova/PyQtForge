# 📦 PyQtForge

> **PyQtForge** is a developer tool that helps you quickly create, manage, and run PyQt5 applications with simple CLI commands.  
> Ideal for fast desktop app development using **Python** and **Qt**.

---

## 🚀 Features

- Scaffold new PyQt5 projects in seconds
- Auto-create and manage virtual environments
- Launch Qt Designer easily
- Convert `.ui` files to `.py` automatically
- Run projects with or without virtual environments
- Simple commands, fast workflows

---

## 📥 Installation

1. Clone the repository:
    ```bash
    git clone https://github.com/tusharNova/pyqtforge.git
    cd pyqtforge
    ```

2. Install in editable mode:
    ```bash
    pip install -e .
    ```

> **Note:** Make sure you have Python 3.8 or higher installed.

---

## 🛠 Requirements

- Python 3.8+
- pyqt5
- pyqt5-tools
- typer
- click

Install manually if needed:

```bash
pip install pyqt5 pyqt5-tools typer click
```

## 🧰 Commands Overview

| Command                                | Description |
|----------------------------------------| ------------- |
| pyqtforge createproject <project_name> | Create a new PyQt project scaffold |
| pyqtforge runproject <project_name>    | Run the project |
| pyqtforge createui <ui_file_name>      | Launch Qt Designer to create .ui files |
| pyqtforge ui2py <ui_file_path>         | Convert a single .ui file to .py |
| pyqtforge ui2py --all                  | Convert all .ui files in ui/ directory |


## 🏗 Project Structure

```text
your_project/
├── ui/
│   └── (your .ui design files)
├── views/
│   └── (converted .py files from .ui)
├── main.py
├── .venv/ (optional)
└── resources/ (optional static files/images)
```

## ⚡ Quickstart Example
- 1 Create a new project:
```bash
   pyqtforge createproject myapp
   cd myapp
```
- 2 Launch Qt Designer:
```bash
   pyqtforge createui mywindow
```
- 3 After designing, convert .ui to .py:
```bash
   pyqtforge ui2py ui/mywindow.ui
```
- 4 Edit your main.py to use the generated Python UI file:
```bash
   from PyQt5 import QtWidgets
   from views.mywindow import Ui_MainWindow
   
   class clsMainWindow(QtWidgets.QMainWindow):
       def __init__(self):
           super(clsMainWindow , self).__init__()
           self.ui = Ui_MainWindow()
           self.ui.setupUi(self)
   
   app = QtWidgets.QApplication([])
   window = MainWindow()
   window.show()
   app.exec_()
```
- 5 Run your project:
```bash
   pyqtforge runproject 
```

## 🤝 Contribution
We welcome contributions to PyQtForge!
- 1 Fork this repository
- 2 Create a feature branch (git checkout -b feature/yourfeature)
- 3 Commit your changes (git commit -m 'Add new feature')
- 4 Push to your branch (git push origin feature/yourfeature)
- 5 Create a Pull Request


#### 💬 Feel free to suggest improvements, report issues, and discuss ideas in Issues tab!

## 📄 License
##### This project is licensed under the MIT License — free to use, modify, and distribute.


#### 🌟 Star the repository if you find it helpful!

## 🔥 Let's build faster, better PyQt apps together!
```yaml

---

✅ **This is the complete and clean `README.md`!**

---

Would you also like me to generate a **`CONTRIBUTING.md`** file too (to guide contributors)? It would make your project even more professional! 🚀  
Want it? 🌟  (Say: "yes")
```

